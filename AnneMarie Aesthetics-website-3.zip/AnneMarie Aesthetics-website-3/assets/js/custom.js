$(document).ready(function () {
    /*======accordion======*/
	$(".accordion > li > span").click(function() {
		$(this).toggleClass("active").next('div').slideToggle(250)
		.closest('li').siblings().find('span').removeClass('active').next('div').slideUp(250);
	});
});
/*======stiky-header======*/
$(window).scroll(function() {
    if ($(window).scrollTop() > 300) { 
        $('.header-area').addClass('fixed_header');
    } else {
        $('.header-area').removeClass('fixed_header');
    }
    if ($(window).scrollTop() > 400) {
        $('.header-area').addClass('stky');
        $('.schedule-button').addClass('active');
    } else {
        $('.header-area').removeClass('stky');
		$('.schedule-button').removeClass('active');
    }
});

var swiper = new Swiper(".home-testimonials-slider .mySwiper", {
    slidesPerView: 1,
    spaceBetween: 30,
    slidesPerGroup: 1,
    loop: true,
    loopFillGroupWithBlank: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".home-testimonials-slider .swiper-button-next",
      prevEl: ".home-testimonials-slider .swiper-button-prev",
    },
  });

  // var swiper = new Swiper(".mySwiper", {
  //   slidesPerView: 1,
  //   spaceBetween: 30,
  //   slidesPerGroup: 1,
  //   loop: true,
  //   loopFillGroupWithBlank: true,
  //   pagination: {
  //     el: ".swiper-pagination",
  //     clickable: true,
  //   },
  //   navigation: {
  //     nextEl: ".swiper-button-next",
  //     prevEl: ".swiper-button-prev",
  //   },
  // });  
  // ========white-sec-inject
  var swiper = new Swiper(".white-inject-slider .swiper-container", {
    slidesPerView: 2,
    spaceBetween: 48,
    pagination: {
      el: ".white-inject-slider .swiper-pagination",
      clickable: true,
    },
    breakpoints: {
      360: {
          slidesPerView: 1,
          spaceBetweenSlides: 30,
      },
      768: {
          slidesPerView: 2,
          spaceBetweenSlides: 48,
      }
  },
  });
  var swiper = new Swiper(".pair-with-botox-slider", {
    slidesPerView: 1,
    spaceBetween: 36,
    pagination: {
      el: ".pair-with-botox-right .swiper-pagination ",
      clickable: true,
    },
    breakpoints: {
      360: {
          slidesPerView: 1,
          spaceBetweenSlides: 30,
      },
      768: {
          slidesPerView: 2,
          spaceBetweenSlides:10,
      },
      992:{
        slidesPerView: 2,
        spaceBetweenSlides: 15,
      }
  },
  });
  // *******************
  var swiper = new Swiper(".testimonial-slider", {
    slidesPerView: 1,
    spaceBetween: 50,
    cssMode: true,
    pagination: {
      el: ".testimonial-right  .swiper-pagination",
      clickable: true,
    },
    mousewheel: true,
    keyboard: true,
    breakpoints: {
        320: {
            slidesPerView: 1,
          spaceBetween:30,
        }
    },
  });
  var swiper = new Swiper(".good-candidate-slider", {
    slidesPerView: 1,
    spaceBetween: 50,
    cssMode: true,
    pagination: {
      el: ".good-candidate-slider .swiper-pagination",
      clickable: true,
    },
    mousewheel: true,
    keyboard: true,
    breakpoints: {
        320: {
            slidesPerView: 1,
          spaceBetween:30,
        }
    },
  });